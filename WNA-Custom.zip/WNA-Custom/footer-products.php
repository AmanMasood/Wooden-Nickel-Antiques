    					<div class="sell-dialog">
    						<?php 
    							//echo do_shortcode( '[contact-form-7 id="110639" title="Sell Your Item"]' );
    							
    							echo do_shortcode('[gravityform id=1 title=false description=false ajax=true tabindex=49]');
    							
    							 ?>
    					</div>
    					
    					<footer id="main-footer" class="footer" role="contentinfo">
    						<div id="inner-footer" class="row">
    							<?php if ( is_active_sidebar( 'footer' ) ) : ?>
    								<?php dynamic_sidebar( 'footer' ); ?>
    							<?php endif; ?>
    						</div> <!-- end #inner-footer -->
    						
    						<div id="copyright-area" class="large-12">
    							<p class="source-org copyright">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?></p>
    						</div>
    					</footer> <!-- end .footer -->
    				</div> <!-- end #container -->
    			</div> <!-- end .inner-wrap -->
    		</div> <!-- end .off-canvas-wrap -->
		</div> <!-- end #global-wrapper -->
		<?php include('parts/product-slides.php'); ?>			
		<?php wp_footer(); ?>
	</body>
</html> <!-- end page -->