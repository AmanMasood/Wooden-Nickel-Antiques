<?php
/*
* Template Name: Contact
*/
?>
<?php get_header(); ?>
	<div id="content">
		<div id="inner-content" class="row">
			<div id="main" class="large-12 medium-12 columns" role="main">
				
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<article id="post-<?php the_ID(); ?>" <?php post_class(''); ?> role="article" itemscope itemtype="http://schema.org/WebPage">
											
						<header class="article-header section-header">
							<h2><?php the_title(); ?></h2>
						</header> <!-- end article header -->
						
						<div class="row">
							<div class="large-5 columns entry-content">
								<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12383.316022605772!2d-84.52!3d39.110363!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0000000000000000%3A0x88049991a950dc06!2sWooden+Nickel+Antiques!5e0!3m2!1sen!2sus!4v1416436437881" width="100%" height="300" frameborder="0" style="border:0"></iframe>
								<br/><br/>
								<p>
									<strong>Wooden Nickel Antiques</strong><br/>
									<strong>Address:</strong> 1410 Central Pkwy, Cincinnati, OH 45202<br/>
									<strong>Phone:</strong> (513) 241-2985<br/>
									<strong>E-mail:</strong> <a href="mailto:woodennickel@fuse.net">woodennickel@fuse.net</a><br/>
								</p>
								<p>
									<strong>Store Hours:</strong><br/>
									<strong>Monday:</strong> 10:00 am – 4:00 pm<br/>
									<strong>Tuesday:</strong> 10:00 am – 4:00 pm<br/>
									<strong>Wednesday:</strong> 10:00 am – 4:00 pm<br/>
									<strong>Thursday:</strong> 10:00 am – 4:00 pm<br/>
									<strong>Friday:</strong> 10:00 am – 4:00 pm<br/>
									<strong>Saturday:</strong> 10:00 am – 4:00 pm<br/>
									<strong>Sunday:</strong> Closed
								</p>
							</div>
							<div class="large-7 columns">
								<section class="entry-content" itemprop="articleBody" style="padding:10px;">
									<?php the_content(); ?>
								</section> <!-- end article section -->
							</div>
						</div>
						<footer class="article-footer">
							
						</footer> <!-- end article footer -->
												
					</article> <!-- end article -->
				<?php endwhile;endif; ?>
				
			</div> <!-- end #main -->		
		</div> <!-- end #inner-content -->
	</div> <!-- end #content -->
<?php get_footer(); ?>