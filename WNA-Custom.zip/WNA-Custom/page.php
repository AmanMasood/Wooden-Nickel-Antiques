<?php get_header(); ?>
<?php 
// Works for now
// Need to remove _llabs_meta serialization so this isn't necessary to query by price.
$args = array(
	'post_type' => 'product',
	'meta_key' => '_llabs_meta',
	'posts_per_page' => -1
);
$query = new WP_Query($args);
if ($query->have_posts()) :
	while ($query->have_posts()) :
		$query->the_post();
		$product_meta = get_post_meta($post->ID,'_llabs_meta',TRUE); 
		if (!empty($product_meta['price'])) {
			$price = $product_meta['price'];
			$price = preg_replace('/([A-Z,\-$ ]){1,}/i','',$price);
			add_post_meta($post->ID,'_price',$price,TRUE);
			update_post_meta($post->ID,'_price',$price);
		}
		if ((empty($price)) || ($price == 0)) {
			// set post to use an old date, so it appears at bottom
			global $wpdb;
			$wpdb->update( 
				'wp_wna_posts', // table
				array( 'post_date' => '2010-00-00 00:00:00' ), // data to update
				array( 'ID' => $post->ID ), // post selector
				array( '%s' ),  // data type, string
				array( '%d' ) // selector type, integer 
			);
		} 
	endwhile;
endif;
?>
	<div id="content">
		<div id="inner-content" class="row">
			<div id="main" class="large-12 medium-12 columns" role="main">
				
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<article id="post-<?php the_ID(); ?>" <?php post_class(''); ?> role="article" itemscope itemtype="http://schema.org/WebPage">					
						<header class="article-header section-header">
							<h2><?php the_title(); ?></h2>
						</header>
						<section class="entry-content" itemprop="articleBody">
							<?php the_content(); ?>
						</section>
						<footer class="article-footer">
						</footer>		
					</article>
					
					<?php 
						// product sorting
						if (isset($_POST['sort-value'])) {
							switch($_POST['sort-value']) {
								case 'low':
									$meta = array(array('key'=>'_price','value'=>0,'compare'=>'>='));
									$orderby = 'meta_value_num';
									$order = 'ASC';
									break;
								case 'high':
									$meta = array(array('key'=>'_price','value'=>-1,'compare'=>'>='));
									$orderby = 'meta_value_num';
									$order = 'DESC';
									break;
								case 'new':
									$meta = '';
									$orderby = 'date';
									$order = 'DESC';
									break;
								case 'old':
									$meta = '';
									$orderby = 'date';
									$order = 'ASC';
									break;
								default:
									// nothing
							}
						} else {
							$meta = array(array('key'=>'_price','value'=>-1,'compare'=>'NOT LIKE'));
							$orderby = 'meta_value_num';
							$order = 'DESC';
						}
						
						// Determine category to display
						switch($post->ID) {
							case 11: // furniture
								$category_query = new WP_Query(array( 
									'post_type' => 'product', 
									'posts_per_page' => -1,
									'cat' => 5,
									'meta_query' => $meta,
									'orderby' => $orderby,
									'order' => $order
									)
								); 
								break;
							case 13: // architecture
								$category_query = new WP_Query(array( 
									'post_type' => 'product', 
									'posts_per_page' => -1,
									'cat' => 3,
									'meta_query' => $meta,
									'orderby' => $orderby,
									'order' => $order						
									)
								); 
								break;
							case 15: // bars
								$category_query = new WP_Query(array( 
									'post_type' => 'product', 
									'posts_per_page' => -1,
									'cat' => 4,
									'meta_query' => $meta,
									'orderby' => $orderby,
									'order' => $order								
									)
								); 
								break;
							case 17: // lighting
								$category_query = new WP_Query(array( 
									'post_type' => 'product', 
									'posts_per_page' => -1,
									'cat' => 6,
									'meta_query' => $meta,
									'orderby' => $orderby,
									'order' => $order									
									)
								); 
								break;
							case 19: // mantels
								$category_query = new WP_Query(array( 
									'post_type' => 'product', 
									'posts_per_page' => -1,
									'cat' => 7,
									'meta_query' => $meta,
									'orderby' => $orderby,
									'order' => $order								
									)
								); 
								break;
							case 21: // stained glass
								$category_query = new WP_Query(array( 
									'post_type' => 'product', 
									'posts_per_page' => -1,
									'cat' => 8,
									'meta_query' => $meta,
									'orderby' => $orderby,
									'order' => $order							
									)
								); 
								break;
							case 23: // decorative arts
								$category_query = new WP_Query(array( 
									'post_type' => 'product', 
									'posts_per_page' => -1,
									'cat' => 9,
									'meta_query' => $meta,
									'orderby' => $orderby,
									'order' => $order									
									)
								); 
								break;
							case 25: // garden
								$category_query = new WP_Query(array( 
									'post_type' => 'product', 
									'posts_per_page' => -1,
									'cat' => 10,
									'meta_query' => $meta,
									'orderby' => $orderby,
									'order' => $order								
									)
								); 
								break;
							case 113412: // music hall
								$category_query = new WP_Query(array( 
									'post_type' => 'product', 
									'posts_per_page' => -1,
									'cat' => 70,
									'meta_query' => $meta,
									'orderby' => $orderby,
									'order' => $order								
									)
								); 
								break;
							default: // no output
								$category_query = new WP_Query(array( 
									'post_type' => 'product', 
									'cat' => 99999,				
									)
								); 
						} ?>
						
						<div class="row">
							<div class="large-6 columns">
								<form method="post" action="">
									<select id="product-sort" name="sort-value" style="width:65%;margin-right:10px;float:left;">
										<option value="" selected disabled>Sort By...</option>
										<option value="low">Sort by Price: Low to High</option>
										<option value="high">Sort by Price: High to Low</option>
										<option value="new">Sort by Date: Newest First</option>
										<option value="old">Sort by Date: Oldest First</option>
									</select>
									<input type="submit" class="button primary radius" style="float:left;padding:6px 25px;" value="Go" />
								</form>
							</div>
						</div>
						<div class="clearfix"></div>
						<?php // product output
						if ($category_query->have_posts()) : while ( $category_query->have_posts() ) : $category_query->the_post(); ?>
							
							<div class="large-3 columns end product-outer">
								<div class="product-image">
									<?php the_post_thumbnail('full'); ?>
								</div>
								<div class="product-detail">
									<?php the_title(); ?>
									<?php $product_meta = get_post_meta($post->ID,'_llabs_meta',TRUE); ?>
									<?php if ((isset($product_meta['price'])) && (($product_meta['price']) != '$0')) {
										echo '<br/>' . $product_meta['price'];
									} else {
										echo '<br/> Call us for pricing';
									} ?>
								</div>
								<div class="light-overlay overlay-on-hover absolute-full"><a style="display:block;height:100%;" href="<?php the_permalink(); ?>"></a></div>
							</div>
							
						<?php endwhile; endif; // product query ?>
						
				<?php endwhile; endif; // page content query ?>
											
			</div> <!-- end #main -->		
		</div> <!-- end #inner-content -->
	</div> <!-- end #content -->
<?php get_footer(); ?>