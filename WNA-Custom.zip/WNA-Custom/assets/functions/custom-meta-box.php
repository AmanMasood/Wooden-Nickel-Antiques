<?php
/******************************
Custom Meta Box Functions
*******************************/

define('MY_WORDPRESS_FOLDER',$_SERVER['DOCUMENT_ROOT']);
define('MY_THEME_FOLDER',str_replace("\\",'/',dirname(__FILE__)));
define('MY_THEME_PATH','/' . substr(MY_THEME_FOLDER,stripos(MY_THEME_FOLDER,'wp-content')));

add_action('add_meta_boxes','llabs_meta_init');
add_action('save_post','llabs_meta_save');

/******************************
Init Function for Meta Boxes 
******************************/
function llabs_meta_init()
{        
    // Get the current page template and post type
    $post_id = $_GET['post'] ? $_GET['post'] : $_POST['post_ID'] ;
    $template_file = get_post_meta($post_id,'_wp_page_template',TRUE);
    $post_type = get_post_type($post_id);
	
    // Continue only if using the product post type
    if ($post_type == 'product') {
    	
		// Meta box styles 
    	wp_enqueue_style('llabs_meta_css', MY_THEME_PATH . '/custom-meta/meta.css');
		
		// Register and enqueue the required javascript for image upload.
		wp_register_script( 'meta-box-image', MY_THEME_PATH . '/custom-meta/meta-box-image.js', array( 'jquery' ) );
    	wp_localize_script( 'meta-box-image', 'meta_image',
    		array(
    			'title' => __( 'Choose or Upload an Image', 'prfx-textdomain' ),
	        	'button' => __( 'Use this image', 'prfx-textdomain' ),
			)
    	);
		wp_enqueue_script( 'meta-box-image' );
		
		
		// Add meta boxes
		add_meta_box('product-info','Product Details','llabs_meta_setup','product','normal','high');
		add_meta_box('product-images','Product Images','llabs_meta_setup','product','normal','high');
		
	}
	if ($post_type == 'home-carousel') {
		
		// Meta box styles 
    	wp_enqueue_style('llabs_meta_css', MY_THEME_PATH . '/custom-meta/meta.css');
		
		// Add meta boxes
		add_meta_box('carousel-details','Carousel Details','llabs_meta_setup','home-carousel','normal','high');
		
	}
	
}

/******************************
Main Output Function for Meta Boxes 
******************************/ 

function llabs_meta_setup($post,$metabox)
{
    global $post;
  
    // using an underscore, prevents the meta variable
    // from showing up in the custom fields section
    $meta = get_post_meta($post->ID,'_llabs_meta',TRUE);

    // instead of defining all the various meta boxes here, lets do an include
    // for now, you'll have to modify this via FTP
    include(MY_THEME_FOLDER . '/custom-meta/meta-definitions.php');

	
    // create a custom nonce for submit verification later
    echo '<input type="hidden" name="llabs_meta_noncename" value="' . wp_create_nonce(__FILE__) . '" />';
}

/******************************
Authenticate & Save Function for Meta Boxes 
******************************/ 
function llabs_meta_save($post_id) 
{

	error_log('starting save');
	
    // authentication checks
    // make sure data came from our meta box
    if (!wp_verify_nonce($_POST['llabs_meta_noncename'],__FILE__)) return $post_id; 

    // check user permissions
    if ($_POST['post_type'] == 'page') 
    {
        if (!current_user_can('edit_page', $post_id)) return $post_id;
    }
    else
    {
        if (!current_user_can('edit_post', $post_id)) return $post_id;
    }
 
    // authentication passed, save data
    $current_data = get_post_meta($post_id, '_llabs_meta', TRUE);  
    
    $new_data = $_POST['_llabs_meta'];
    llabs_meta_clean($new_data);
	
    if ($current_data) 
    {
        if (is_null($new_data)) delete_post_meta($post_id,'_llabs_meta');
        else update_post_meta($post_id,'_llabs_meta',$new_data);
    }
    elseif (!is_null($new_data))
    {
        add_post_meta($post_id,'_llabs_meta',$new_data,TRUE);
    }
 
    return $post_id;
}

/******************************
Sanitize Function for Meta Boxes 
******************************/     
function llabs_meta_clean(&$arr)
{
    if (is_array($arr))
    {
        foreach ($arr as $i => $v)
        {
            if (is_array($arr[$i])) 
            {
                llabs_meta_clean($arr[$i]);
 
                if (!count($arr[$i])) 
                {
                    unset($arr[$i]);
                }
            }
            else
            {
                if (trim($arr[$i]) == '') 
                {
                    unset($arr[$i]);
                }
            }
        }
 
        if (!count($arr)) 
        {
            $arr = NULL;
        }
    }
}

/******************************
End Meta Box Functions
******************************/
?>