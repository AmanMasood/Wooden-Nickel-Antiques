<?php
function joints_scripts_and_styles() {
  global $wp_styles; // Call global $wp_styles variable to add conditional wrapper around ie stylesheet the WordPress way
  if (!is_admin()) {
    $theme_version = '1.6.14';

		// Removes WP version of jQuery
		wp_deregister_script('jquery');
		//wp_deregister_script('sf_main');
		
		// Loads jQuery from vendor Files
		wp_enqueue_script( 'jquery', get_template_directory_uri() . '/assets/vendor/foundation/js/vendor/jquery.js', array(), '2.1.3', true );
		
		// Loads jQuery from vendor Files
		//wp_enqueue_script( 'sf_main', get_template_directory_uri() . '/assets/js/superfly-menu.min.js', array('jquery'), $theme_version, true );
			
		// Modernizr from vendor Files
		wp_enqueue_script( 'modernizr', get_template_directory_uri() . '/assets/vendor/foundation/js/vendor/modernizr.js', array(), '2.8.3', true );
		
		// Adding Foundation scripts file in the footer
		wp_enqueue_script( 'foundation-js', get_template_directory_uri() . '/assets/vendor/foundation/js/foundation.min.js', array( 'jquery' ), '', true );
	 
		// Slick JS Carousel
		wp_enqueue_script( 'slick-js', get_template_directory_uri() . '/assets/js/slick.min.js', array( 'jquery' ), '1.5.7b', true );
		 
		// Cycle2 Slider
		wp_enqueue_script( 'cycle-js', get_template_directory_uri() . '/assets/js/jquery.cycle2.min.js', array( 'jquery' ), '2.1.6b', true );

		// Jquery UI
		wp_enqueue_script( 'jquery-ui', get_template_directory_uri() . '/assets/js/jquery-ui.min.js', array( 'jquery' ), '1.11.4b', true );
		
		// Jquery Zoom
		wp_enqueue_script( 'jquery-zoom', get_template_directory_uri() . '/assets/js/jquery.elevatezoom.js', array( 'jquery' ), $theme_version, true );
		
		// Adding scripts file in the footer
		wp_enqueue_script( 'site-js', get_template_directory_uri() . '/assets/js/scripts.js', array( 'jquery','cycle-js','jquery-zoom' ), $theme_version, true );
		
		// Normalize from vendor files
		wp_enqueue_style( 'normalize-css', get_template_directory_uri() . '/assets/vendor/foundation/css/normalize.min.css', array(), '', 'all' );      
		
		// Adding Foundation styles
		wp_enqueue_style( 'foundation-css', get_template_directory_uri() . '/assets/vendor/foundation/css/foundation.min.css', array(), '', 'all' );
	 
		// Register Joints stylesheet
		wp_enqueue_style( 'joints-css', get_template_directory_uri() . '/assets/css/style.css', array(), $theme_version, 'all' );
		
		// Register Slick stylesheet
		wp_enqueue_style( 'slick-css', get_template_directory_uri() . '/assets/css/slick.css', array(), '1.5.7b', 'all' );
		
		// Register jquery UI stylesheet
		wp_enqueue_style( 'jquery-ui-css', get_template_directory_uri() . '/assets/css/jquery-ui.min.css', array(), '1.11.4', 'all' );

		// Register main stylesheet
		wp_enqueue_style( 'main-css', get_template_directory_uri() . '/style.css', array(), $theme_version, 'all' );
		
		// Product Slides CSS
		wp_enqueue_style( 'products-css', get_template_directory_uri() . '/assets/css/product-slides.css', array(), $theme_version, 'all' );
		
    // Comment reply script for threaded comments
    if ( is_singular() AND comments_open() AND (get_option('thread_comments') == 1)) {
      wp_enqueue_script( 'comment-reply' );
    }
  }
}
add_action('wp_enqueue_scripts', 'joints_scripts_and_styles', 999);
?>