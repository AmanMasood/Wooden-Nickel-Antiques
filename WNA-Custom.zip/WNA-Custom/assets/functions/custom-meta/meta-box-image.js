/*
 * Attaches the image uploader to the input field
 */
jQuery(document).ready(function($){
    
	// Modify as needed - must match the IDs of meta box buttons
    $('#image1').click(meta_image_attach);
	$('#image2').click(meta_image_attach);
	$('#image3').click(meta_image_attach);
	$('#image4').click(meta_image_attach);
	$('#image5').click(meta_image_attach);
	$('#image6').click(meta_image_attach);
	$('#image7').click(meta_image_attach);
	$('#image8').click(meta_image_attach);
	$('#image9').click(meta_image_attach);
	$('#image10').click(meta_image_attach);
	
	function meta_image_attach(e){

		// Instantiates the variable that holds the media library frame.
		var meta_image_frame;		
        
		// Prevents the default action from occuring.
        e.preventDefault();		
			
		// If the frame already exists, re-open it.
        if ( meta_image_frame ) {
            meta_image_frame.open();
            return;
        }
 
        // Sets up the media library frame
        meta_image_frame = wp.media.frames.meta_image_frame = wp.media({
            title: meta_image.title,
            button: { text:  meta_image.button },
            library: { type: 'image' }
        });
 
        // Runs when an image is selected.
        meta_image_frame.on('select', function(){
 
            // Grabs the attachment selection and creates a JSON representation of the model.
            var media_attachment = meta_image_frame.state().get('selection').first().toJSON();
			
			// Determine which button was clicked
			var	idClicked = e.target.id;
			
			// Sends the attachment URL to our custom image input field.
            $('#'+idClicked+'-val').val(media_attachment.url);
        });
 
        // Opens the media library frame.
        meta_image_frame.open();
    };
	
});



