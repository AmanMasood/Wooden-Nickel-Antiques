<?php
/* 
* This file defines our custom meta box content
**/

if ($metabox['id'] == 'product-info') {

?>

	<div class="llabs_meta_control">
		<label>Product ID (SKU):</label>
		<p><input type="text" name="_llabs_meta[sku]" value="<?php if(!empty($meta['sku'])) echo esc_html($meta['sku']); ?>" /></p>

		<label>Price:</label>
		<p><input type="text" name="_llabs_meta[price]" value="<?php if(!empty($meta['price'])) echo esc_html($meta['price']); ?>" /></p>
		
		<label>Dimensions:</label>
		<p><input type="text" name="_llabs_meta[dimensions]" value="<?php if(!empty($meta['dimensions'])) echo esc_html($meta['dimensions']); ?>" /></p>
	</div>
	
<?php } elseif ($metabox['id'] == 'product-images') { ?>

	<div class="llabs_meta_control">
		<label>Image 1:</label>
		<p>
			<input type="text" id="image1-val" name="_llabs_meta[image1]" value="<?php if(!empty($meta['image1'])) echo ($meta['image1']); ?>" />
			<input type="button" id="image1" class="button" value="Choose or Upload an Image" />
		</p>

		<label>Image 2:</label>
		<p>	
			<input type="text" id="image2-val" name="_llabs_meta[image2]" value="<?php if(!empty($meta['image2'])) echo ($meta['image2']); ?>" />
			<input type="button" id="image2" class="button" value="Choose or Upload an Image" />
		</p>
		
		<label>Image 3:</label>
		<p>
			<input type="text" id="image3-val" name="_llabs_meta[image3]" value="<?php if(!empty($meta['image3'])) echo ($meta['image3']); ?>" />
			<input type="button" id="image3" class="button" value="Choose or Upload an Image" />
		</p>
		
		<label>Image 4:</label>
		<p>
			<input type="text" id="image4-val" name="_llabs_meta[image4]" value="<?php if(!empty($meta['image4'])) echo ($meta['image4']); ?>" />
			<input type="button" id="image4" class="button" value="Choose or Upload an Image" />
		</p>
		
		<label>Image 5:</label>
		<p>
			<input type="text" id="image5-val" name="_llabs_meta[image5]" value="<?php if(!empty($meta['image5'])) echo ($meta['image5']); ?>" />
			<input type="button" id="image5" class="button" value="Choose or Upload an Image" />
		</p>
		
		<label>Image 6:</label>
		<p>
			<input type="text" id="image6-val" name="_llabs_meta[image6]" value="<?php if(!empty($meta['image6'])) echo ($meta['image6']); ?>" />
			<input type="button" id="image6" class="button" value="Choose or Upload an Image" />
		</p>
		
		<label>Image 7:</label>
		<p>
			<input type="text" id="image7-val" name="_llabs_meta[image7]" value="<?php if(!empty($meta['image7'])) echo ($meta['image7']); ?>" />
			<input type="button" id="image7" class="button" value="Choose or Upload an Image" />
		</p>

		<label>Image 8:</label>
		<p>
			<input type="text" id="image8-val" name="_llabs_meta[image8]" value="<?php if(!empty($meta['image8'])) echo ($meta['image8']); ?>" />
			<input type="button" id="image8" class="button" value="Choose or Upload an Image" />
		</p>
		
		<label>Image 9:</label>
		<p>
			<input type="text" id="image9-val" name="_llabs_meta[image9]" value="<?php if(!empty($meta['image9'])) echo ($meta['image9']); ?>" />
			<input type="button" id="image9" class="button" value="Choose or Upload an Image" />
		</p>
		
		<label>Image 10:</label>
		<p>
			<input type="text" id="image10-val" name="_llabs_meta[image10]" value="<?php if(!empty($meta['image10'])) echo ($meta['image10']); ?>" />
			<input type="button" id="image10" class="button" value="Choose or Upload an Image" />
		</p>
	</div>

<?php } elseif ($metabox['id'] == 'carousel-details') { ?>
		<label>Link to Product:</label>
		<p><input type="text" style="width:100%;" name="_llabs_meta[link]" value="<?php if(!empty($meta['link'])) echo esc_html($meta['link']); ?>" /></p>

	
<?php } ?>