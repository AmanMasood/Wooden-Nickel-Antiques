<?php
/*
 * Custom Post Types
 * All of our custom post types are
 * defined on this page.
 */

add_action( 'init', 'bwd_product_post_type' );
add_action( 'init', 'bwd_mosaic_post_type' );
add_action( 'init', 'bwd_carousel_post_type' );
add_action( 'init', 'bwd_blurb_post_type' );

// Products
function bwd_product_post_type() { 
	register_post_type( 'product',
		array('labels' => array(
			'name' => 'Products',
			'singular_name' => 'Product',
			'all_items' => 'All Products',
			'add_new' => 'Add New',
			'add_new_item' => 'Add New Product',
			'edit' => 'Edit',
			'edit_item' => 'Edit Product',
			'new_item' => 'New Product',
			'view_item' => 'View Products',
			'search_items' => 'Search Products',
			'not_found' =>  __('Nothing found in the Database.', 'jointstheme'),
			'not_found_in_trash' => __('Nothing found in Trash', 'jointstheme'),
			'parent_item_colon' => ''
			), /* end of arrays */
			'description' => 'Products',
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false,
			'show_ui' => true,
			'query_var' => true,
			'menu_position' => 30,
			'menu_icon' => get_stylesheet_directory_uri() . '/assets/images/custom-post-icon.png',
			'rewrite'	=> array( 'slug' => 'product', 'with_front' => false ),
			'has_archive' => true,
			'capability_type' => 'post',
			'hierarchical' => false,
			'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'sticky', 'page-attributes'),
			'taxonomies' => array('category'),
	 	) /* end of options */
	); /* end of register post type */	
} 

// Home Mosaic Items
function bwd_mosaic_post_type() { 
	register_post_type( 'mosaic',
		array('labels' => array(
			'name' => 'Mosaic Menu',
			'singular_name' => 'Menu Item',
			'all_items' => 'All Menu Items',
			'add_new' => 'Add New',
			'add_new_item' => 'Add New Menu Item',
			'edit' => 'Edit',
			'edit_item' => 'Edit Menu Item',
			'new_item' => 'New Menu Item',
			'view_item' => 'View Menu Items',
			'search_items' => 'Search Menu Items',
			'not_found' =>  __('Nothing found in the Database.', 'jointstheme'),
			'not_found_in_trash' => __('Nothing found in Trash', 'jointstheme'),
			'parent_item_colon' => ''
			), /* end of arrays */
			'description' => 'Menu Items on Home Page',
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => true,
			'show_ui' => true,
			'query_var' => true,
			'menu_position' => 31,
			'menu_icon' => get_stylesheet_directory_uri() . '/assets/images/custom-post-icon.png',
			'rewrite'	=> array( 'slug' => 'mosaic', 'with_front' => false ),
			'has_archive' => false,
			'capability_type' => 'post',
			'hierarchical' => false,
			'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'sticky', 'page-attributes')
	 	) /* end of options */
	); /* end of register post type */	
} 

// Home carousel
function bwd_carousel_post_type() { 
	register_post_type( 'home-carousel',
		array('labels' => array(
			'name' => 'Carousel Images',
			'singular_name' => 'Carousel Image',
			'all_items' => 'All Carousel Images',
			'add_new' => 'Add New',
			'add_new_item' => 'Add New Carousel Image',
			'edit' => 'Edit',
			'edit_item' => 'Edit Carousel Image',
			'new_item' => 'New Carousel Image',
			'view_item' => 'View Carousel Images',
			'search_items' => 'Search Carousel Images',
			'not_found' =>  __('Nothing found in the Database.', 'jointstheme'),
			'not_found_in_trash' => __('Nothing found in Trash', 'jointstheme'),
			'parent_item_colon' => ''
			), /* end of arrays */
			'description' => 'Carousel Images for Home Page',
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => true,
			'show_ui' => true,
			'query_var' => true,
			'menu_position' => 32,
			'menu_icon' => get_stylesheet_directory_uri() . '/assets/images/custom-post-icon.png',
			'rewrite'	=> array( 'slug' => 'home-carousel', 'with_front' => false ),
			'has_archive' => false,
			'capability_type' => 'post',
			'hierarchical' => false,
			'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'sticky', 'page-attributes')
	 	) /* end of options */
	); /* end of register post type */	
}	
	// Whats Inside Blurbs
function bwd_blurb_post_type() { 
	register_post_type( 'blurb',
		array('labels' => array(
			'name' => "What's Inside",
			'singular_name' => "What's Inside Item",
			'all_items' => 'All Items',
			'add_new' => 'Add New',
			'add_new_item' => 'Add New Item',
			'edit' => 'Edit',
			'edit_item' => 'Edit Item',
			'new_item' => 'New Item',
			'view_item' => 'View Items',
			'search_items' => 'Search Items',
			'not_found' =>  __('Nothing found in the Database.', 'jointstheme'),
			'not_found_in_trash' => __('Nothing found in Trash', 'jointstheme'),
			'parent_item_colon' => ''
			), /* end of arrays */
			'description' => "What's Inside Items for Home Page",
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => true,
			'show_ui' => true,
			'query_var' => true,
			'menu_position' => 33,
			'menu_icon' => get_stylesheet_directory_uri() . '/assets/images/custom-post-icon.png',
			'rewrite'	=> array( 'slug' => 'whats-inside', 'with_front' => false ),
			'has_archive' => false,
			'capability_type' => 'post',
			'hierarchical' => false,
			'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'sticky', 'page-attributes')
	 	) /* end of options */
	); /* end of register post type */	
} 

?>