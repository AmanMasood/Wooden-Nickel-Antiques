// Global variables
var wOffsetY = window.pageYOffset;
var mobileCheck = null; 
var panelHeight = null;
var throttled;
var throttledTwo;
var mouseEnterThrottled;
var mouseMoveThrottled;
var mouseEnterAllowed = false;
var mouseMoveAllowed = true;
var zoomLevel = 1.3;
var zoomLevelInitial = zoomLevel;
var zoomState = false;
var altInitialWidth = false;
var altInitialHeight = false;

jQuery(document).ready(function($) {
	
	// load foundation
	$(document).foundation();
	
	// Remove empty P tags created by WP inside of Accordion and Orbit
	jQuery('.accordion p:empty, .orbit p:empty').remove();
	jQuery('.archive-grid .columns').last().addClass('end');

	// Mobile check function
	mobileCheck = jQuery('.show-for-large').css('display');
	jQuery(window).on('resize', function(){
		mobileCheck = jQuery('.show-for-large').css('display');
	});
			
	// slick image carousel
	$('.carousel-container').slick({
		dots: false,
		infinite: true,
		speed: 300,
		slidesToShow: 1,
		centerMode: true,
		variableWidth: true,
		prevArrow: '<i id="prevArrow" class="fa fa-chevron-left"></i>',
		nextArrow: '<i id="nextArrow" class="fa fa-chevron-right"></i>'
	});
	$('#gal_01').slick({
		dots:false,
		infinite: false,
		speed: 300,
		slidesToShow: 3,
		centerMode:false,
		variableWidth: true,
		prevArrow: '<i id="prevArrow" class="fa fa-chevron-left"></i>',
		nextArrow: '<i id="nextArrow" class="fa fa-chevron-right"></i>'
	});

	// add mobile menu functionality to tablets
	$('.toggle-topbar a').click(function(){
		if ($('.small-tablet-selector').css('display') === 'block') {
			if ($('nav.top-bar').hasClass('expanded')) {
				$('nav.top-bar').removeClass('expanded');
			} else {
				$('nav.top-bar').addClass('expanded');
			};
		};	
	});
	
	// close mobile nav when a link is clicked
	$('.top-bar-section li a').click(function(){
		$('nav.top-bar').removeClass('expanded');
	});

	// dialog and lightbox functions
	$('.dialogbox').dialog({
		modal: true,
		autoOpen: false,
		width:800,
		title: "Contact Us"
	});
	
	// dialog and lightbox functions
	$('.sell-dialog').dialog({
		modal: true,
		autoOpen: false,
		width:800,
		title: "Sell Us Your Item"
	});
	
	$('.sell-item').click(function(event){
		$('.sell-dialog').dialog('open');
		$('#subject-line').val('Item For Sale');
		$('#product-message').html('Dear Wooden Nickel Antiques: I am interested in selling the following item: ');
	});
	
	$('#contact').click(function(event){
		var product = $('.product-title').text();
		var sku = $('#sku').text();
		var price = $('#price').text();
		$('.dialogbox').dialog('open');
		$('#subject-line').val('Inquiry about Item #' + sku);
		$('#product-message').text('Dear Wooden Nickel Antiques: I am interested the ' + product + ', item #' + sku + ', which you have listed at a price of "' + price + '". Please contact me at your earliest convenience. Thank you!');
		$('#product-link').val(window.location.href);
	});
	
	$('#contact-slider').click(function(event){
		var product = $('.product-title').text();
		var sku = $('#sku').text();
		var price = $('#price').text();
		$('.dialogbox').dialog('open');
		$('#subject-line').val('Inquiry about Item #' + sku);
		$('#product-message').text('Dear Wooden Nickel Antiques: I am interested the ' + product + ', item #' + sku + ', which you have listed at a price of "' + price + '". Please contact me at your earliest convenience. Thank you!');
		$('#product-link').val(window.location.href);
	});
	
	// temp fix to logo link in SF menu
	$('.sf-logo a').attr('href','https://www.woodennickelantiques.net/');
	
	
	
	/*****************************************************
	# Slidepanel functionality
	/*****************************************************/
	
		$(window).on('load', loadCarousel);
		$(window).resize(function() {
			if ($('body').hasClass('modal-open')) {
				clearTimeout(throttled);
				clearTimeout(throttledTwo);
				if ($(window).width() < 1025) {
					$('#slidemodalx').click();
				} 
				throttled = setTimeout(resizeCarousel, 100);
				throttledTwo = setTimeout(resizeSlides, 100);
			}
		});
	
		/*****************************************************
		# Click Events
		/*****************************************************/	
			
			// open modal
			$('#content .slidespawn').click(function(){				
				
				clearTimeout(mouseEnterThrottled);
				mouseEnterThrottled = setTimeout(function() {
					mouseEnterAllowed = true;
				}, 100);
				
				wOffsetY = window.pageYOffset;
				var targetSlide = $(this).attr('id');
				var targetSlide = document.getElementById('slide-' + targetSlide);
				var slideNum = targetSlide.dataset.slideNum;
				
				$('body').addClass('modal-open');			
				$('#slidemodal').css({'z-index':'9999999','display':'none'});
				$('#slidemodal').fadeIn();	
				$('#cycle-1').cycle('goto', slideNum);
				$('#cycle-1 .cycle2-image').each(resizeSlides);
				resizeCarousel();
				zoomLevel = zoomLevelInitial;	
			});
			
			// close modal
			$('#slidemodalx').click(function(){
				$('#slidemodal').hide();
				$('body').removeClass('modal-open');
				$(window).scrollTop(wOffsetY);

				mouseEnterAllowed = false;
				mouseMoveAllowed = true;
				zoomLevel = 1.3;
				zoomLevelInitial = zoomLevel;
				zoomState = false;
				altInitialWidth = false;
				altInitialHeight = false;
			});
			
			// advance main slideshow when clicking carousel photo
			$('#cycle-2 .cycle-slide').click(function(){			
				var index = $('#cycle-2').data('cycle.API').getSlideIndex(this);
				$(this).addClass('cycle-slide-active');
				$('#cycle-2 .cycle-slide-active').removeClass('cycle-slide-active');
				$('#cycle-1').cycle('goto', index);
			});

			// advance the other slideshow when clicking arrows
			var slideshows = $('.cycle-slideshow').on('cycle-next cycle-prev', function(e, opts) {
				slideshows.not(this).cycle('goto', opts.currSlide);
			}); 

			// toggle zoom function when clicking on image
			$('.cycle2-vertical .slideimg').click(function(event){
				toggleZoom(event);
			});
			
			
		/*****************************************************
		# Slideshow Before/After Events
		/*****************************************************/	
		
			$('#cycle-1').on('cycle-before', function() {			
				
				altInitialWidth = false;
				altInitialHeight = false;
				$('#slidemodal').css('overflow-x','hidden');
				$('#cycle-1 .cycle-slide-active').css('opacity','0');
				$('#slidemodal #cycle-1 .cycle-slide-active').css({'align-items':'center'});
				$('#slidemodal #cycle-1 .cycle-slide-active').css({'height':'100%','width':'100%'});
				
				if (zoomState) {
					zoomState = false;
					zoomLevel = zoomLevelInitial;
					$('#slidemodal').removeClass('zoomed');
					resizeSlides();			
				}
				
			});

			$('#cycle-1').on('cycle-after', function() {
				$('#slidemodal').css('overflow-x','auto');
			});

		/*****************************************************
		# General Functions
		/*****************************************************/
			
			function toggleZoom(event) {				
				$('#slidemodal #cycle-1 .cycle-slide-active').css({'height':'100%','width':'100%','align-items':'center'});
				if (zoomState) {		
					zoomState = false; // toggle off
					zoomLevel = 1;
					$('#slidemodal').removeClass('zoomed');
					altInitialWidth = false;
					altInitialHeight = false;
				}	else {		
					zoomState = true; // toggle on
					zoomLevel = zoomLevelInitial;
					$('#slidemodal').addClass('zoomed');												
				}			
				loadCarousel();			
				
				if ((event) && (zoomState)) {
					
					// if they click outside the image, change target to image instead of container
					var $target = $(event.target);
					if ($target.hasClass('cycle-slide-active')) {
						$target = $target.find('img');
					}

					var $targetContainer = $target.parent('.test-container');
					var dims = getDimsAndCoords(event,$target,$targetContainer);
					
					$target.css({'width':dims.zoomWidth,'height':dims.zoomHeight});	
					$target.css({'left':dims.coords.moveX * -1,'top':dims.coords.moveY * -1});
					
				}	
				return;		
				
			};		

			function loadCarousel() {
				resizeSlides();
				resizeCarousel();
				zoomState ? bindMouseEvents() : unbindMouseEvents();
			};

			function unbindMouseEvents() {
				$('#cycle-1 .test-container').each(function(){
					$(this).off('mouseleave',handlerMouseLeave);
					$(this).off('mouseenter',handlerMouseEnter);
					$(this).off('mousemove',handlerMouseMove);
					$(this).off('mousewheel DOMMouseScroll MozMousePixelScroll',handlerMouseWheel);				
				});			
			};

			function bindMouseEvents() {
				var $targetImage = $('#cycle-1 .cycle-slide-active .cycle2-image');
				var $targetContainer = $('#cycle-1 .cycle-slide-active .test-container');
				$targetContainer.bind('mouseleave',handlerMouseLeave);
				$targetContainer.bind('mouseenter',handlerMouseEnter);
				$targetContainer.bind('mousemove',handlerMouseMove);
				$targetContainer.bind('mousewheel DOMMouseScroll MozMousePixelScroll',handlerMouseWheel);	
			};

		/*****************************************************
		# Mouse Event Handlers
		/*****************************************************/
		
			function handlerMouseLeave(event) {
				var $target = $(event.target);
				var $targetContainer = $target.parent('.test-container');
				$target.css({'top':0,'left':0});		
				$targetContainer.css({'box-shadow':'none'});
				resizeSlides();			
			};
			
			function handlerMouseMove(event) {
				if (!mouseMoveAllowed) return false;
				
				// if they click outside the image, change target to image instead of container
				var $target = $(event.target);
				if ($target.hasClass('test-container')) {
					$target = $target.find('img');
				}
				
				var $targetContainer = $target.parent('.test-container');
				var dims = getDimsAndCoords(event,$target,$targetContainer);
				$target.css({'left':dims.coords.moveX * -1,'top':dims.coords.moveY * -1});
				
				mouseMoveAllowed = false;				
				clearTimeout(mouseEnterThrottled);
				mouseMoveThrottled = setTimeout(function() {
					mouseMoveAllowed = true;
				}, 12);
				
			};	
			
			function handlerMouseEnter(event) {			
				if (!mouseEnterAllowed) return false;
				var $target = $(event.target);
				var $targetContainer = $target.parent('.test-container');
				var dims = getDimsOnly(event,$target,$targetContainer);	
				$target.css({'width':dims.zoomWidth,'height':dims.zoomHeight});		
			};
		
			function handlerMouseWheel(event) {					
				var yOffset = window.pageYOffset;
				var xOffset = window.pageXOffset;
				var newOffsetY = 0;
				var newOffsetX = 0;
				var screenHeight = $(window).height();
				var screenWidth = $(window).width();
				var theEvent = event.originalEvent.wheelDelta || event.originalEvent.detail*-1
				
				var $target = $(event.target);
				var $targetContainer = $target.parent('.test-container');
				
				event.stopImmediatePropagation();
				event.stopPropagation();
				event.preventDefault();
				event.originalEvent.stopImmediatePropagation();
				event.originalEvent.stopPropagation();
				event.originalEvent.preventDefault();
				
				// scrolling up or down
				if ((theEvent / 120 > 0) && (zoomLevel < 3)) {
					zoomLevel = zoomLevel + 0.1;
				} else if ((theEvent / 120 < 0) && (zoomLevel > 1)) {
					zoomLevel = zoomLevel - 0.1;								
				}	else {
					return false;
				}
				
				mouseMoveAllowed = false;
				clearTimeout(mouseMoveThrottled);
				mouseMoveThrottled = setTimeout(function() {
					mouseMoveAllowed = true;
				}, 100);
				
				var dims = getDimsAndCoords(event,$target,$targetContainer);
				
				$target.css({'width':dims.zoomWidth,'height':dims.zoomHeight});		
				$target.css({'top':dims.coords.moveY * -1,'left':dims.coords.moveX * -1});		
			};
			
		/*****************************************************
		# Mouse Event Support Functions
		/*****************************************************/
		
			// get image dimensions for mouse event handlers
			function getDimsOnly(event,$target,$targetContainer) {		

				if (altInitialHeight) {
					var nWidth = altInitialWidth;
					var nHeight = altInitialHeight;	
				} else {
					var nWidth = $target.prop('naturalWidth');
					var nHeight = $target.prop('naturalHeight');	
				}
		
				var paintedWidth = $target.width();
				var paintedHeight = $target.height();

				if ((nWidth > paintedWidth) || (nHeight > paintedHeight)) {
					nWidth = paintedWidth;
					nHeight = paintedHeight;
					// store in global
					altInitialWidth = paintedWidth;
					altInitialHeight = paintedHeight;
				}
				
				if (zoomState) {								
					var containerHeight = $('#cycle-1').height();
					var containerWidth = $('#cycle-1').width();
					var zoomWidth = nWidth * (zoomLevel + 0.3);
					var zoomHeight = nHeight * (zoomLevel + 0.3);
					var nWidth = containerWidth;
					var nHeight = containerHeight;
				} else {		
					var zoomWidth = nWidth * zoomLevel;
					var zoomHeight = nHeight * zoomLevel;				
				}			
				
				var dims = {
					'zoomWidth' : zoomWidth,
					'zoomHeight' : zoomHeight,
					'nWidth' : nWidth,
					'nHeight' : nHeight
				};			
				return dims;	
			};
				
			// get image dimensions AND mouse coordinations for mouse event handlers
			// more expensive call
			function getDimsAndCoords(event,$target,$targetContainer) {				

				var dims = getDimsOnly(event,$target,$targetContainer);
				var diffWidth = Math.ceil(dims.zoomWidth - dims.nWidth);
				var diffHeight = Math.ceil(dims.zoomHeight - dims.nHeight);

				var pointerPositionX = event.pageX;
				var pointerPositionY = event.pageY;
				
				var targetOffset = $targetContainer.offset();
				var relativePositionX = pointerPositionX - (dims.nWidth/2);
				var relativePositionY = pointerPositionY - targetOffset.top;
	
				var ratioX = diffWidth / dims.nWidth;
				var ratioY = diffHeight / dims.nHeight;				
				var moveX = Math.ceil(relativePositionX * ratioX);
				var moveY = Math.ceil(relativePositionY * ratioY);

				dims.coords = {'moveX':moveX, 'moveY':moveY};
				return dims;
			}
		
		
		/*****************************************************
		# Slide & Carousel Resize Functions
		/*****************************************************/
	
			function resizeCarousel() {	
				if (($('#slidemodal').css('display') == 'block') || ($('#slidemodal').css('display') == 'flex')) {		
				
					var opts = $('#cycle-2').data('cycle.API').getSlideOpts(this);
					var visCount = opts.carouselVisible || opts.slides.length;
					var dim = visCount * $(opts.slides[0])['outerWidth'](true);
					var offset = 0;
					
					opts.container['width'](dim);

					var tmp = opts._carouselWrap.children();
					var slideWidth = $(tmp[0])['outerWidth'](true);

					// opts.currSlide is zero indexed. opts.slides.length is not, +1 to adjust
					var difference = (opts.slides.length - (opts.currSlide+1));
					var moveTo = (difference < 4) ? (opts.slides.length - 5) : opts.currSlide;
					if (moveTo < 0) var moveTo = 0;
					
					var offset = offset-(slideWidth * moveTo);
					opts._carouselWrap.css('left', offset);		
				};	
			};

			// Reset product slideshow images to their correct size
			// Needed on initial load, and when resizing window.		
			function resizeSlides() {		
					
				var $activeImage = $('#cycle-1 .cycle-slide-active .cycle2-image');
				var $activeContainer = $('#cycle-1 .cycle-slide-active .test-container');
				$activeImage.css({'top':0,'left':0});	
					
				$('#slidemodal #cycle-1 img').each(function() {
					
					var containerHeight = $('#cycle-1').height();
					var containerWidth = $('#cycle-1').width();
					var nWidth = $(this).prop('naturalWidth');
					var nHeight = $(this).prop('naturalHeight');
					var $targetContainer = $(this).parent('.test-container');
								
					if ((zoomState) && (($targetContainer).parents('.cycle-slide-active').length)) {			

						if (altInitialHeight) {
							var nWidth = altInitialWidth;
							var nHeight = altInitialHeight;	
						} else {
							var nWidth = $activeImage.prop('naturalWidth');
							var nHeight = $activeImage.prop('naturalHeight');	
						}
				
						var paintedWidth = $activeImage.width();
						var paintedHeight = $activeImage.height();

						if ((nWidth > paintedWidth) || (nHeight > paintedHeight)) {
							nWidth = paintedWidth;
							nHeight = paintedHeight;
							altInitialWidth = paintedWidth;
							altInitialHeight = paintedHeight;
						}

						$activeContainer.css({'width':containerWidth,'height':containerHeight});
						/*$activeImage.css({'width':zoomWidth,'height':zoomHeight});						*/
					
					} else {

						if ((nWidth > containerWidth) && (nHeight > containerHeight)) {
							
							// If the image naturally exceeds the width & height of the container, needs special handling
							// this takes care of very large images, or when the user is on a small screen (or high browser zoom)
						
							nWidth = 'auto';
							nHeight = '100%';
							$targetContainer.css({'width':'auto','height':containerHeight,'overflow':'hidden','position':'relative'});
							$(this).css({'width':nWidth,'height':nHeight});
							
							var paintedWidth = $targetContainer.width();
							var paintedHeight = $targetContainer.height();
							$targetContainer.css({'width':paintedWidth,'height':paintedHeight});
							
							return;
							
						} else {				
							
							// When width or height exceed the container (but not both)
							// find the "good" value and set the other to auto
							
							if ((nWidth > containerWidth) || (nHeight > containerHeight)) {
								
								var diffWidth = nWidth - containerWidth;
								var diffHeight = nHeight - containerHeight;	
								if (diffWidth >= diffHeight) {
									nWidth = (nWidth - diffWidth);
									nHeight = 'auto';						
								} else {
									nHeight = (nHeight - diffHeight);
									nWidth = 'auto';
								};						
							};	
							
						};
						
						// 1. resize the image based on known values
						// 2. resize container automatically with the image
						// 3. get the actual container size
						// 4. add explicit width & height values to container (doesn't affect appearance, but needed for other functions)
				
						$(this).css({'width':nWidth,'height':nHeight});			
						$targetContainer.css({'width':nWidth,'height':nHeight,'overflow':'hidden','position':'relative'});			
						var paintedWidth = $targetContainer.width();
						var paintedHeight = $targetContainer.height();
						$targetContainer.css({'width':paintedWidth,'height':paintedHeight});
					
					};
						
				});	
				return;
			};		
					
		/************************************
		END SLIDE PANELS
		************************************/	
});