// Global variables
var wOffsetY = window.pageYOffset;
var mobileCheck = null; 
var panelHeight = null;
var throttled;
var throttledTwo;
var zoomLevel = 1.5;
var zoomLevelOriginal = 1.5 
var zoomState = false;
var mouseZoomInitial = 1.5;

jQuery(document).ready(function($) {
	
	// load foundation
	$(document).foundation();
	
	// Remove empty P tags created by WP inside of Accordion and Orbit
	jQuery('.accordion p:empty, .orbit p:empty').remove();
	jQuery('.archive-grid .columns').last().addClass('end');

	// Mobile check function
	mobileCheck = jQuery('.show-for-large').css('display');
	jQuery(window).on('resize', function(){
		mobileCheck = jQuery('.show-for-large').css('display');
	});
			
	// slick image carousel
	$('.carousel-container').slick({
		dots: false,
		infinite: true,
		speed: 300,
		slidesToShow: 1,
		centerMode: true,
		variableWidth: true,
		prevArrow: '<i id="prevArrow" class="fa fa-chevron-left"></i>',
		nextArrow: '<i id="nextArrow" class="fa fa-chevron-right"></i>'
	});
	$('#gal_01').slick({
		dots:false,
		infinite: false,
		speed: 300,
		slidesToShow: 3,
		centerMode:false,
		variableWidth: true,
		prevArrow: '<i id="prevArrow" class="fa fa-chevron-left"></i>',
		nextArrow: '<i id="nextArrow" class="fa fa-chevron-right"></i>'
	});

	// add mobile menu functionality to tablets
	$('.toggle-topbar a').click(function(){
		if ($('.small-tablet-selector').css('display') === 'block') {
			if ($('nav.top-bar').hasClass('expanded')) {
				$('nav.top-bar').removeClass('expanded');
			} else {
				$('nav.top-bar').addClass('expanded');
			};
		};	
	});
	
	// close mobile nav when a link is clicked
	$('.top-bar-section li a').click(function(){
		$('nav.top-bar').removeClass('expanded');
	});

	// dialog and lightbox functions
	$('.dialogbox').dialog({
		modal: true,
		autoOpen: false,
		width:800,
		title: "Contact Us"
	});
	
	// dialog and lightbox functions
	$('.sell-dialog').dialog({
		modal: true,
		autoOpen: false,
		width:800,
		title: "Sell Us Your Item"
	});
	
	$('.sell-item').click(function(event){
		$('.sell-dialog').dialog('open');
		$('#subject-line').val('Item For Sale');
		$('#product-message').html('Dear Wooden Nickel Antiques: I am interested in selling the following item: ');
	});
	
	$('#contact').click(function(event){
		var product = $('.product-title').text();
		var sku = $('#sku').text();
		var price = $('#price').text();
		$('.dialogbox').dialog('open');
		$('#subject-line').val('Inquiry about Item #' + sku);
		$('#product-message').text('Dear Wooden Nickel Antiques: I am interested the ' + product + ', item #' + sku + ', which you have listed at a price of "' + price + '". Please contact me at your earliest convenience. Thank you!');
		$('#product-link').val(window.location.href);
	});
	
	$('#contact-slider').click(function(event){
		var product = $('.product-title').text();
		var sku = $('#sku').text();
		var price = $('#price').text();
		$('.dialogbox').dialog('open');
		$('#subject-line').val('Inquiry about Item #' + sku);
		$('#product-message').text('Dear Wooden Nickel Antiques: I am interested the ' + product + ', item #' + sku + ', which you have listed at a price of "' + price + '". Please contact me at your earliest convenience. Thank you!');
		$('#product-link').val(window.location.href);
	});
	
	// temp fix to logo link in SF menu
	$('.sf-logo a').attr('href','http://www.woodennickelantiques.net/');
	
	// old zoom feature (elevateZoom)
	/*
	mainWidth = parseInt(($('#main').css('width')));
	loadGallery(mainWidth);
	
	$( window ).resize(function() {
		mainWidth = parseInt(($('#main').css('width')));
		loadGallery(mainWidth);
	});
	*/	
	/*
	function loadGallery(mainWidth) {
		if (mainWidth <= 757) {
			$("#zoom_1").elevateZoom({
				easing:false,
				gallery:"gal_01", 
				galleryActiveClass:"active",
				zoomType: "inner", 
				cursor: "crosshair",
				scrollZoom : true,
				tint:true,
				tintColour:'#F90',
				tintOpacity:0.5,	
			});	
		} else {
			$("#zoom_1").elevateZoom({	
				easing:false,
				gallery:"gal_01", 
				galleryActiveClass:"active",	
				zoomWindowPosition:11,
				zoomWindowOffetx:-100,
				scrollZoom : true,
				tint:true,
				tintColour:'#F90',
				tintOpacity:0.5,	
			});	
		}	
	}
	*/
		/*****************************************************
	# SLIDEPANELS REALLY NEED CLEANUP / CONSOLIDATION
	# Slidepanel functionality
	/*****************************************************/
		
		$('#content .slidespawn').click(function(){		
				
			wOffsetY = window.pageYOffset;
			var targetSlide = $(this).attr('id');
			var targetSlide = document.getElementById('slide-' + targetSlide);
			var slideNum = targetSlide.dataset.slideNum;
			
			$('body').addClass('modal-open');
			$('body').css('top',-wOffsetY + 'px');				
			
			$('#slidemodal').css({'z-index':'9999999','display':'none'});
			$('#slidemodal').fadeIn();
			
			$('#cycle-1').cycle('goto', slideNum);
			$('#cycle-1 .cycle2-image').each(resizeSlides);
			zoomLevel = 1;	

		});
		
		$('#slidemodalx').click(function(){
			$('#slidemodal').hide();
			$('body').removeClass('modal-open');
			$(window).scrollTop(wOffsetY);
			if ($('#slidemodal').hasClass('zoomed')) {
				toggleZoom();
			};
		});
		
		// cycle2 pagers
		// advance the other slideshow when clicking arrows, remove zoom mode
		var slideshows = $('.cycle-slideshow').on('cycle-next cycle-prev', function(e, opts) {
			slideshows.not(this).cycle('goto', opts.currSlide);
		}); 
		
		// advance main slideshow when clicking carousel photo
		$('#cycle-2 .cycle-slide').click(function(){			
			var index = $('#cycle-2').data('cycle.API').getSlideIndex(this);
			$(this).addClass('cycle-slide-active');
			$('#cycle-2 .cycle-slide-active').removeClass('cycle-slide-active');
			$('#cycle-1').cycle('goto', index);
		});
		
		// zoom class allows slideshow overflow while zoomed in
		// $('.cycle2-vertical .slideimg').click(toggleZoom);
		
		$('#cycle-1').on('cycle-before', function() {
			$('#cycle-1 .cycle-slide-active').css('opacity','0');
			$('#slidemodal').css('overflow-x','hidden');
			$('#cycle-1').css('overflow','hidden');
			if (!zoomState) {
				zoomLevel = 1;
			} else {
				zoomLevel = zoomLevelOriginal;
			}
			resizeSlides();
			$('#slidemodal #cycle-1 .cycle-slide-active').css({'align-items':'center'});
			$('#slidemodal #cycle-1 .cycle-slide-active').css({'height':'100%','width':'100%'});	
		});
		
		$('#cycle-1').on('cycle-after', function() {
			$('#slidemodal').css('overflow-x','auto');
			$('#cycle-1').css('overflow','auto');
			bindScrollEvent();
			if (!zoomState) {
					/*
					$('#cycle-1 .cycle-slide-active img').elevateZoom({	
						cursor: 'crosshair',
						scrollZoom: true,
						zoomWindowWidth: 200,
						zoomWindowHeight: 200,
						zoomType: 'inner',		
					});	
					*/
					// add zoom box
					/*
					$('#cycle-1 #zoomBox').trigger('zoom.destroy');
					$('#cycle-1 #zoomBox').remove();
					$('#cycle-1 .cycle-slide-active').append('<div id="zoomBox"></div>');
					$('#cycle-1 .cycle-slide-active').zoom({
						target: '#zoomBox',
						magnify: 1.5				
					});
					var zWidth = (parseInt($('.cycle-slide-active > img').css('width')) / 2) + 'px';
					var zHeight = (parseInt($('.cycle-slide-active > img').css('height')) / 2) + 'px';
					$('#zoomBox').css({'width':zWidth,'height':zHeight});
					$('#zoomBox').on('mousemove', function(e) {
						
						var self = this;
						self.lastX = e.clientX;
						self.lastY = e.clientY;    
				
						setPosition: function(e) {
		
							var self = this;
							self.$elem = $('#zoomBox img');
							self.nzHeight = self.$elem.height();
							self.nzWidth = self.$elem.width();
							self.nzOffset = self.$elem.offset();

							//container fix
							$('#zoomBox').css({ top: self.nzOffset.top});
							$('#zoomBox').css({ left: self.nzOffset.left});
							self.mouseLeft = parseInt(e.pageX - self.nzOffset.left);
							self.mouseTop = parseInt(e.pageY - self.nzOffset.top);

							//calculate the bound regions for inner zoom
							self.Etoppos = (self.mouseTop < ((self.nzHeight/2)/self.heightRatio) );
							self.Eboppos = (self.mouseTop > (self.nzHeight - ((self.nzHeight/2)/self.heightRatio)));
							self.Eloppos = (self.mouseLeft < 0+(((self.nzWidth/2)/self.widthRatio)));
							self.Eroppos = (self.mouseLeft > (self.nzWidth - (self.nzWidth/2)/self.widthRatio-(self.options.lensBorderSize*2)));  

							// if the mouse position of the slider is one of the outerbounds, then hide  window and lens
							if (self.mouseLeft < 0 || self.mouseTop < 0 || self.mouseLeft > self.nzWidth || self.mouseTop > self.nzHeight ) {				          
								self.setElements("hide");
								return;
							}
							//else continue with operations
						}
						*/
			}
		});
		
		// toggle slideshow zoom on or off
		function toggleZoom() {	
			$('#slidemodal #cycle-1 .cycle-slide-active').css({'height':'100%','width':'100%'});	
			$('#slidemodal #cycle-1 .cycle-slide-active').css({'align-items':'center'});
			if (zoomState) {	
			
				zoomState = false;
				$('#slidemodal').removeClass('zoomed');
				resizeSlides();
				bindScrollEvent();
				/*	
				// add zoom box
				$('#cycle-1 #zoomBox').trigger('zoom.destroy');
				$('#cycle-1 #zoomBox').remove();
				$('#cycle-1 .cycle-slide-active').append('<div id="zoomBox"></div>');
				$('#cycle-1 .cycle-slide-active').zoom({
					target: '#zoomBox',
					magnify: 1.5				
				});
				var zWidth = $('.cycle-slide-active > img').css('width');
				var zHeight = $('.cycle-slide-active > img').css('height');
				$('#zoomBox').css({'width':zWidth,'height':zHeight});
				*/
				
			}	else {	
			
				zoomState = true;
				/*
				$('#cycle-1 #zoomBox').trigger('zoom.destroy');
				$('#cycle-1 #zoomBox').remove();
				*/
				$('#slidemodal').addClass('zoomed');
				resizeSlides();
				bindScrollEvent();
			}
			return;
		};
				
		function resizeSlides() {				
			
			zoomLevel = zoomLevelOriginal;
			if (zoomState) {
				// images should be zoomed, enlarge them
				$('#slidemodal #cycle-1 img').each(function(){
					var screenHeight = $(window).height();
					var screenWidth = $(window).width();
					var nWidth = $(this).prop('naturalWidth');
					var nHeight = $(this).prop('naturalHeight');
					var zoomWidth = nWidth * zoomLevel;
					var zoomHeight = nHeight * zoomLevel;
					$(this).parent('.test-container').css({'width':zoomWidth,'height':zoomHeight,'overflow':'hidden','position':'relative'});
					
					if ((zoomWidth > screenWidth) || (zoomHeight > screenHeight)) {							
						var diffWidth = zoomWidth - screenWidth;
						var diffHeight = zoomHeight - screenHeight;		
						if (diffWidth >= diffHeight) {
							zoomWidth = (zoomWidth - diffWidth);
							zoomHeight = 'auto';						
						} else {
							zoomHeight = (zoomHeight - diffHeight);
							zoomWidth = 'auto';
						};
					};							
					$(this).css({'width':zoomWidth,'height':zoomHeight});		
				});			
				
			} else {
				// images should not be zoomed, resize to fit containzer
				$('#slidemodal #cycle-1 img').each(function(){
					var containerHeight = $('#cycle-1').height();
					var containerWidth = $('#cycle-1').width();
					var nWidth = $(this).prop('naturalWidth');
					var nHeight = $(this).prop('naturalHeight');
					$(this).parent('.test-container').css({'width':nWidth,'height':nHeight,'overflow':'hidden','position':'relative'});

					if ((nWidth > containerWidth) || (nHeight > containerHeight)) {
						if ((nWidth > containerWidth) && (nHeight > containerHeight)) {
							nWidth = 'auto';
							nHeight = 'auto';
						} else {
							var diffWidth = nWidth - containerWidth;
							var diffHeight = nHeight - containerHeight;	
							if (diffWidth >= diffHeight) {
								nWidth = (nWidth - diffWidth);
								nHeight = 'auto';						
							} else {
								nHeight = (nHeight - diffHeight);
								nWidth = 'auto';
							};						
						};
					};
					$(this).css({'width':nWidth,'height':nHeight});	
				});
			};	
			return;
		};
		
		function resizeCarousel() {	
			// When user zooms or resizes window in slideshow mode, the bottom thumbnails get out of alignment
			// this function should fix it in most cases
			// TO DO - need to handle the situation where a customer closes the modal, then zooms, then reopens screen (it wont adjust as of now)
			// this will break the carousel if run when its not visible
			
			if (($('#slidemodal').css('display') == 'block') || ($('#slidemodal').css('display') == 'flex')) {			
				
				var opts = $('#cycle-2').data('cycle.API').getSlideOpts(this);
				var visCount = opts.carouselVisible || opts.slides.length;
				var dim = visCount * $(opts.slides[0])['outerWidth'](true);
				var offset = 0;
				
				// set container width
				opts.container['width'](dim);
				
				// put individual slides in array
				var tmp = opts._carouselWrap.children();
				var slideWidth = $(tmp[0])['outerWidth'](true);
				
				// carousel should always show the current slide plus another 4.
				// if less than 4 slides remain, stop moving carousel
				// when user reaches the end, wrap back to zero.
				
				// opts.currSlide is zero indexed. opts.slides.length is not, +1 to adjust
				var difference = (opts.slides.length - (opts.currSlide+1));
				var moveTo = (difference < 4) ? (opts.slides.length - 5) : opts.currSlide;
				if (moveTo < 0) var moveTo = 0;
				
				var offset = offset-(slideWidth * moveTo);
				opts._carouselWrap.css('left', offset);
				bindScrollEvent();
			};
		};	
		
		function bindScrollEvent() {
			if (!zoomState) {
				zoomLevel = 1;
			}
			$('#cycle-1 .cycle-slide-active .cycle2-image').bind('mousemove', function(e) {
				var $targetImage = $('#cycle-1 .cycle-slide-active .cycle2-image');
				var $targetContainer = $('#cycle-1 .cycle-slide-active .test-container');
				
				var nWidth = $targetImage.prop('naturalWidth');
				var nHeight = $targetImage.prop('naturalHeight');
				var zoomWidth = nWidth * mouseZoomInitial;
				var zoomHeight = nHeight * mouseZoomInitial;
				var diffWidth = zoomWidth - nWidth;
				var diffHeight = zoomHeight - nHeight;

				var pointerPositionX = e.pageX;
				var pointerPositionY = e.pageY;
				var targetOffset = $targetContainer.offset();
        var relativePositionX = pointerPositionX - targetOffset.left;
        var relativePositionY = pointerPositionY - targetOffset.top;
				
        diffWidth = Math.ceil(zoomWidth - nWidth);
        diffHeight = Math.ceil(zoomHeight - nHeight);

        // For when the zoom image is smaller than the flyout element.
        if (diffWidth < 0) diffWidth = 0;
        if (diffHeight < 0) diffHeight = 0;

        var ratioX = diffWidth / nWidth;
        var ratioY = diffHeight / nHeight;

				var moveX = Math.ceil(relativePositionX * ratioX);
        var moveY = Math.ceil(relativePositionY * ratioY);
	
				$targetImage.css({'top':moveY * -1,'left':moveX * -1});	
				
			});
			
			$('#slidemodal').bind('mousewheel DOMMouseScroll MozMousePixelScroll', function(e) {
				
				var yOffset = window.pageYOffset;
				var xOffset = window.pageXOffset;
				var newOffsetY = 0;
				var newOffsetX = 0;
				var screenHeight = $(window).height();
				var screenWidth = $(window).width();
				var theEvent = e.originalEvent.wheelDelta || e.originalEvent.detail*-1
				
				var $targetImage = $('#cycle-1 .cycle-slide-active .cycle2-image');
				var $targetContainer = $('#cycle-1 .cycle-slide-active .test-container');

				e.stopImmediatePropagation();
				e.stopPropagation();
				e.preventDefault();

				var beforeWidth = $targetImage.width();
				var beforeHeight = $targetImage.height();	
				var zoomingIn = false;
				
				// scrolling up or down
				if ((theEvent / 120 > 0) && (zoomLevel < 3)) {
					zoomLevel = zoomLevel + 0.1;
					zoomingIn = true;
				} else if ((theEvent / 120 < 0) && (zoomLevel > 1)) {
					zoomLevel = zoomLevel - 0.1;			
					zoomingIn = false;					
				}	else {
					return false;
				}
				
				var nWidth = $targetImage.prop('naturalWidth');
				var nHeight = $targetImage.prop('naturalHeight');
				var zoomWidth = nWidth * zoomLevel;
				var zoomHeight = nHeight * zoomLevel;
				var diffWidth = zoomWidth - nWidth;
				var diffHeight = zoomHeight - nHeight;
				var changeHeight = zoomHeight - beforeHeight;
				var changeWidth = zoomWidth - beforeWidth;
			
				var pointerPositionX = e.pageX;
				var pointerPositionY = e.pageY;
				var targetOffset = $targetContainer.offset();
        var relativePositionX = pointerPositionX - targetOffset.left;
        var relativePositionY = pointerPositionY - targetOffset.top;
				
        diffWidth = Math.ceil(zoomWidth - nWidth);
        diffHeight = Math.ceil(zoomHeight - nHeight);

        // For when the zoom image is smaller than the flyout element.
        if (diffWidth < 0) diffWidth = 0;
        if (diffHeight < 0) diffHeight = 0;

        var ratioX = diffWidth / nWidth;
        var ratioY = diffHeight / nHeight;

				var moveX = Math.ceil(relativePositionX * ratioX);
        var moveY = Math.ceil(relativePositionY * ratioY);
				
				$targetImage.css({'width':zoomWidth,'height':zoomHeight,'position':'absolute'});		
				$targetImage.css({'top':moveY * -1,'left':moveX * -1});	
				return;		
				
				
				/* KEEP THIS
				var yOffset = window.pageYOffset;
				var xOffset = window.pageXOffset;
				var newOffsetY = 0;
				var newOffsetX = 0;
				var screenHeight = $(window).height();
				var screenWidth = $(window).width();
				var theEvent = e.originalEvent.wheelDelta || e.originalEvent.detail*-1

				if (zoomState) {
					var $scrollContainer = $('#slidemodal');
				} else {
					var $scrollContainer = $('#cycle-1');
				}
				
				var $targetImage = $('#cycle-1 .cycle-slide-active .cycle2-image');
				var $activeSlide = $('#slidemodal #cycle-1 .cycle-slide-active');
				var $zoomedSlide = $('#slidemodal.zoomed #cycle-1 .cycle-slide-active');
				
				var mouseX = e.pageX;
				var mouseY = e.pageY;
				
				// we want this to be the same after zooming	
				var relativeXPercent = parseFloat(mouseX / $targetImage.width()).toFixed(2);
				var relativeYPercent = parseFloat(mouseY / $targetImage.height()).toFixed(2);	

				e.stopImmediatePropagation();
				e.stopPropagation();
				e.preventDefault();

				var beforeWidth = $targetImage.width();
				var beforeHeight = $targetImage.height();	
				var zoomingIn = false;
				
				// scrolling up or down
				if ((theEvent / 120 > 0) && (zoomLevel < 3)) {
					zoomLevel = zoomLevel + 0.1;
					zoomingIn = true;
				} else if ((theEvent / 120 < 0) && (zoomLevel > 0.8)) {
					zoomLevel = zoomLevel - 0.1;			
					zoomingIn = false;					
				}	else {
					return false;
				}
				
				var nWidth = $targetImage.prop('naturalWidth');
				var nHeight = $targetImage.prop('naturalHeight');
				var zoomWidth = nWidth * zoomLevel;
				var zoomHeight = nHeight * zoomLevel;
				var diffWidth = zoomWidth - nWidth;
				var diffHeight = zoomHeight - nHeight;
				var changeHeight = zoomHeight - beforeHeight;
				var changeWidth = zoomWidth - beforeWidth;
				
				$targetImage.css({'width':zoomWidth,'height':zoomHeight});		
				
				if ((zoomHeight > screenHeight) && (zoomWidth > screenWidth)) {
					$activeSlide.css({'align-items':'baseline'});
					$activeSlide.css({'height':zoomHeight});	
					$activeSlide.css({'width':zoomWidth});	
					newOffsetY = diffHeight / 2;
					newOffsetX = diffWidth / 2;
				} 
				else if ((zoomHeight > screenHeight) && (zoomWidth <= screenWidth)) {
					$activeSlide.css({'align-items':'baseline'});
					$activeSlide.css({'height':zoomHeight});	
					$activeSlide.css({'width':'100%'});	
					newOffsetY = diffHeight / 2;
				} 
				else if ((zoomHeight <= screenHeight) && (zoomWidth > screenWidth)) {
					$activeSlide.css({'align-items':'center'});
					$activeSlide.css({'height':'100%'});
					$activeSlide.css({'width':zoomWidth});	
					newOffsetX = diffWidth / 2;			
				}
				else {
					$activeSlide.css({'align-items':'center'});
					$activeSlide.css({'height':'100%'});
					$activeSlide.css({'width':'100%'});	
				}		
				
				var afterWidth = $targetImage.width();
				var afterHeight = $targetImage.height();
				
				// we want this to be the same after zooming	
				var newRelativeX = parseFloat(mouseX / afterWidth).toFixed(2);
				var newRelativeY = parseFloat(mouseY / afterHeight).toFixed(2);
				
				var currentPositionX = parseFloat(newRelativeX * afterWidth).toFixed(2);
				var currentPositionY = parseFloat(newRelativeY * afterHeight).toFixed(2);
				var desiredPositionX = parseFloat(relativeXPercent * afterWidth).toFixed(2);
				var desiredPositionY = parseFloat(relativeYPercent * afterHeight).toFixed(2);
				var moveX = (desiredPositionX - currentPositionX);
				var moveY = (desiredPositionY - currentPositionY);
				
				var currentScrollX = parseFloat($scrollContainer.scrollLeft()).toFixed(2);
				var currentScrollY = parseFloat($scrollContainer.scrollTop()).toFixed(2);
				
				if (zoomingIn) {
					var newPosX = parseFloat((currentScrollX * 1.05) + moveX).toFixed(2);
					var newPosY = parseFloat((currentScrollY * 1.05) + moveY).toFixed(2);
				} else {
					var newPosX = parseFloat((currentScrollX * 0.95) + moveX).toFixed(2);
					var newPosY = parseFloat((currentScrollY * 0.95) + moveY).toFixed(2);				
				}
				
				$scrollContainer.scrollLeft(newPosX);
				$scrollContainer.scrollTop(newPosY);
		
				console.log('----------------------');
				console.log('Relative Position A: [' + relativeXPercent + ' | ' + relativeYPercent + ']');		
				console.log('Relative Position B: [' + newRelativeX + ' | ' + newRelativeY + ']');				
				console.log('Image Dimensions A: [' + beforeWidth + ' x ' + beforeHeight + ']');
				console.log('Image Dimensions B: [' + afterWidth + ' x ' + afterHeight + ']');
				console.log('Current Focus Area: ['  + currentPositionX + ' | ' + currentPositionY + ']');
				console.log('Desired Focus Area: ['  + desiredPositionX + ' | ' + desiredPositionY + ']');			
				console.log('Scroll By: [' + newPosX + ' | ' + newPosY + ']');
				return;		
				*/
			});
		};
					
		$(window).on('load', resizeCarousel);
		$(window).resize(function() {
			clearTimeout(throttled);
			clearTimeout(throttledTwo);
			throttled = setTimeout(resizeCarousel, 100);
			throttledTwo = setTimeout(resizeSlides, 100);
		});
			

		/************************************
		END SLIDE PANELS
		************************************/	
});