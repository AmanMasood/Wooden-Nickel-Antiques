<div class="row">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		
		<div class="large-3 columns end product-outer">
			<div class="product-image">
				<?php the_post_thumbnail('full'); ?>
			</div>
			<div class="product-detail">
				<?php the_title(); ?>
				<?php $product_meta = get_post_meta($post->ID,'_llabs_meta',TRUE); ?>
				<?php if ((isset($product_meta['price'])) && (($product_meta['price']) != '$0')) {
					echo '<br/>' . $product_meta['price'];
				} else {
					echo '<br/> Call us for pricing';
				} ?>
			</div>
			<div class="light-overlay overlay-on-hover absolute-full"><a style="display:block;height:100%;" href="<?php the_permalink(); ?>"></a></div>
		</div>
		
	<?php endwhile;endif; ?>	
</div>