<div class="show-for-below-ipad">
	<div class="small-tablet-selector" style="display:none;"></div>
	<nav class="top-bar" data-topbar>
		<ul class="title-area">
			<!-- Title Area -->			
			<li class="name">
				<h1><a href="<?php echo home_url(); ?>" rel="nofollow"><?php bloginfo('name'); ?></a></h1>
			</li>
			<li class="toggle-topbar menu-icon">
				<a href="#"><span></span></a>
			</li>
		</ul>		
		<section class="top-bar-section">
			<div class="top-bar-container">
				<div class="nav-triangle"></div>
				<?php joints_top_nav(); ?>
			</div>
		</section>
	</nav>
</div>