<?php
// get our product info
$product_meta = get_post_meta($post->ID,'_llabs_meta',TRUE); 
$category = get_the_category();
$sku = '';
$dimensions = '';
$price = '';

if (!empty($product_meta['sku'])) {
	$sku = $product_meta['sku'];
}
if (!empty($product_meta['dimensions'])) {
	$dimensions = $product_meta['dimensions'];
}
if (!empty($product_meta['price'])) {
	$price = $product_meta['price'];
}

$cat_id = $category[0]->term_id;
$top_cats = array(3,4,5,6,7,8,9,10);

if (!in_array($cat_id, $top_cats)) {
	$cat_id = $category[0]->category_parent;
}

switch ($cat_id) {
	case 3: // architecture
		$cat_link = site_url() . '/architectural-salvage/';
		break;
	case 4: // bars
		$cat_link = site_url() . '/antique-bars/';
		break;
	case 5: // furniture
		$cat_link = site_url() . '/antique-furniture/';
		break;
	case 6: // lighting
		$cat_link = site_url() . '/lighting/';
		break;
	case 7: // mantels
		$cat_link = site_url() . '/restored-mantels/';
		break;
	case 8: // stained glass
		$cat_link = site_url() . '/stained-glass/';
		break;
	case 9: // decorative arts
		$cat_link = site_url() . '/decorative-arts/';
		break;
	case 10: // garden
		$cat_link = site_url() . '/garden/';
		break;
	default: 
		// no output
}

if (isset($category[1])) {
	$breadcrumb = '<a href="' . site_url() . '/">Home</a> &raquo; <a href="' . $cat_link . '">' . $category[0]->cat_name . '</a> &raquo; <a href="' . get_category_link($category[1]->term_id) . '">' . $category[1]->cat_name . '</a> &raquo; ' . get_the_title();
} else {
	$breadcrumb = '<a href="' . site_url() . '/">Home</a> &raquo <a href="' . $cat_link . '">' . $category[0]->cat_name . '</a> &raquo ' . get_the_title();
}

?>
<div class="product-breadcrumb">
	<?php echo $breadcrumb; ?>
</div>
<article id="post-<?php the_ID(); ?>" <?php post_class(''); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">
						
	<header class="article-header section-header">	
		<?php $category = get_the_category(); ?>
		<h2 class="entry-title single-title" itemprop="headline"><?php echo $category[0]->cat_name; ?></h2>
	</header> <!-- end article header -->
					
	<section class="entry-content" itemprop="articleBody">
		<div class="large-6 medium-12 columns">
			<h1 class="product-title"><?php the_title(); ?></h1>
			<div class="product-content">
				<?php the_content(); ?>
			</div>
			<div class="product-specs">
				<?php if ($sku) { echo '<p><strong>Item Number:</strong> <span id="sku">' . $sku . '</span></p>'; } ?>
				<?php if ($dimensions) { echo '<p><strong>Dimensions:</strong> <span id="dimensions">' . $dimensions . '</span></p>'; } ?>
				<?php if ($price) { echo '<p><strong>Price:</strong> <span id="price">' . $price . '</span></p>'; } ?>
			</div>
			<p><strong>INTERESTED IN THIS ITEM?</strong></p>
			<p><a id="contact" href="#" class="button radius alert">Contact Us</a></p>
		</div>
		<div class="large-6 medium-12 columns show-for-large-up">
			<?php 
				// product images
				// stores URL of image, not full details
				if (isset($product_meta['image1'])) {
					
					// init image arrays
					$image_full = array();
					$image_thumb = array();
					
					// get all images
					for ($i = 1; $i <= 10; $i++) {
						$image = 'image' . $i;
						if (isset($product_meta[$image])) {
						
							// add full image to array
							array_push($image_full, $product_meta[$image]);
							
							// modify link for thumbnail, and add to thumb array
							$temp_string = substr($product_meta[$image], 0, -4); //remove .jpg
							$thumb = $temp_string . '-125x125.jpg'; //add 125x125.jpg
							array_push($image_thumb, $thumb);
							
						}
					}
					
					// output primary image
					echo '<a id="0" class="slidespawn">';
					echo '<img id="primary-image" src="' . $product_meta['image1'] . '" data-zoom-image="' . $product_meta['image1'] . '" alt="' . get_the_title() . '" />';
					echo '</a>';
					echo '<div class="product-gallery">';
						for ($x = 1; $x < (sizeof($image_full)); $x++) {
							echo '<div class="gallery-image"><a id="' . $x . '" class="slidespawn">';
								echo '<img src="' . $image_thumb[$x] . '" alt="' . get_the_title() . '" class="product-thumb" />';
							echo '</a></div>';
						}					
					echo '</div>';
				} else {
					the_post_thumbnail('full');
				}
			?>
		</div>
		<div class="small-12 columns show-for-medium-down">
			<?php
				// product images
				if (isset($product_meta['image1'])) {
					
					// output individual images in gallery
					for ($x = 0; $x < (sizeof($image_full)); $x++) {
						echo '<img src="' . $image_full[$x] . '" alt="' . get_the_title() . '" />';
					}
					
				} else {
					the_post_thumbnail('full');
				}
			?>
		</div>
	</section> <!-- end article section -->		
	<footer class="article-footer">
		<div class="large-12 columns" style="margin-top:75px;">
			<?php echo '<p><a href="' . $cat_link . '">Back to ' . $category[0]->cat_name . ' &raquo</a>'; ?>
		</div>
	</footer> <!-- end article footer -->

	<div class="dialogbox"><?php echo do_shortcode( '[contact-form-7 id="110638" title="Product Interest"]' ); ?></div>
</article> <!-- end article -->