<?php
// Product Slideshows
	$product_id = get_queried_object_id();
	$product_meta = get_post_meta($product_id,'_llabs_meta',TRUE); 
	$images = array();
	
	if (isset($product_meta['image1'])) :
		
		for ($i = 1; $i <= 10; $i++) {
			$img_key = 'image' . $i;
			if (isset($product_meta[$img_key])) {
				array_push($images, $product_meta[$img_key]);
			}
		}
	endif;
	
	$image_html = '';
	$thumb_html = '';
	$slide_count = 5;
	$image_count = sizeof($images);
	
	if ($image_count < 5) $slide_count = $image_count;

	if ($image_count >= 1) :
		for ($x = 0; $x < (sizeof($images)); $x++) {
			// images for main slider
			$image_html .= '<div id="slide-' . $x . '" class="slideimg" data-slide-num="' . $x . '">';			
			$image_html .= '<div class="test-container"><img class="cycle2-image" src="' . $images[$x] . '" data-zoom-image="' . $images[$x] . '" /></div></div>';	
			// thumbnail images for pager
			$temp_string = substr($images[$x], 0, -4); //remove .jpg
			$thumb = $temp_string . '-125x125.jpg'; //add 125x125.jpg
			$thumb_html .= '<div id="thumb-' . $x . '" class="slideimg thumbpager" data-slide-num="' . $x . '">';			
			$thumb_html .= '<img class="cycle2-image" src="' . $thumb. '" /></div>';	
		}
	endif;
?>

<div id="slidemodal">
	<div id="slidemodalx">Close</div>
	<div class="cycle2-container">
		<div class="cycle2-vertical">
			<div id="cycle-1" class="cycle-slideshow" 
				data-cycle-speed="300"
				data-cycle-fx="scrollHorz" 
				data-cycle-timeout="0" 
				data-cycle-prev=".slide-prev" 
				data-cycle-next=".slide-next" 
				data-cycle-caption="#image-caption"
				data-cycle-caption-template="Image {{slideNum}} / {{slideCount}}"
				data-cycle-log="false" 
				data-cycle-swipe="true"
				data-cycle-slides="> div"
			>
				<?php echo $image_html; ?>
			</div>

			<a class="slide-prev prevslide" id="prev">
				<svg id="leftarrow" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
					<path d="M19.6,29.5c-0.2,0-0.5-0.1-0.6-0.3L8.7,16.6c-0.2-0.3-0.2-0.8,0-1.1L18.9,2.8c0.3-0.3,0.8-0.4,1.1-0.1s0.4,0.8,0.1,1.2
					L10.4,16l9.7,12.1c0.3,0.3,0.2,0.8-0.1,1.2C19.9,29.4,19.7,29.5,19.6,29.5z"/>
				</svg>
			</a> 
			<a class="slide-next nextslide" id="next">
				<svg id="rightarrow" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
					<path d="M10.3,2.5c0.2,0,0.5,0.1,0.6,0.3l10.2,12.7c0.2,0.3,0.2,0.8,0,1.1L10.9,29.2c-0.3,0.3-0.8,0.4-1.1,0.1
					c-0.3-0.3-0.4-0.8-0.1-1.2L19.5,16L9.7,3.9C9.4,3.6,9.5,3.1,9.8,2.7C10,2.6,10.1,2.5,10.3,2.5z"/>
				</svg>
			</a>
				
		</div>
	</div>
	<footer class="footer slide-footer">
		<div id="product-name"><span><?php echo get_the_title(); ?></span></div>
		<?php // <div id="image-caption"></div> ?>
		<div id="slideshow-2">
			<div id="cycle-2" class="cycle-slideshow"
        data-cycle-slides="> div"
        data-cycle-timeout="0"
        data-cycle-prev="#slideshow-2 .cycle-prev"
        data-cycle-next="#slideshow-2 .cycle-next"
        data-cycle-caption="#slideshow-2 .custom-caption"
        data-cycle-caption-template="Slide {{slideNum}} of {{slideCount}}"
        data-cycle-fx="carousel"
        data-cycle-carousel-visible="<?php echo $slide_count; ?>"
        data-cycle-carousel-fluid="false"
        data-allow-wrap="false"
        >
        <?php echo $thumb_html; ?>
			</div>
		</div>
		<div id="contact-area"><a id="contact-slider" href="#" class="button radius alert">Contact Us</a></div>
	</footer>
</div>