<?php get_header(); ?>
<?php

	$category = get_the_category();
	if ($category) {
		$parent_id = $category[1]->category_parent;
		if ($parent_id === 0) {
			$parent_id = $category[0]->category_parent;
		}
		if ($parent_id !== 0) {
			$parent_name = get_the_category_by_ID($parent_id);
		

			switch ($parent_id) {
				case 3: // architecture
					$cat_link = site_url() . '/architectural-salvage/';
					break;
				case 4: // bars
					$cat_link = site_url() . '/antique-bars/';
					break;
				case 5: // furniture
					$cat_link = site_url() . '/antique-furniture/';
					break;
				case 6: // lighting
					$cat_link = site_url() . '/lighting/';
					break;
				case 7: // mantels
					$cat_link = site_url() . '/restored-mantels/';
					break;
				case 8: // stained glass
					$cat_link = site_url() . '/stained-glass/';
					break;
				case 9: // decorative arts
					$cat_link = site_url() . '/decorative-arts/';
					break;
				case 10: // garden
					$cat_link = site_url() . '/garden/';
					break;
				case 70: // music hall
					$cat_link = site_url() . '/music-hall/';
				default: 
					// no output
			}
			
			// compile breadcrumb
			$breadcrumb = '<a href="' . site_url() . '/">Home</a> &raquo <a href="' . $cat_link . '">' . $parent_name . '</a> &raquo ' . get_the_archive_title();
		}
	}

?>
	<div id="content">
	
		<div id="inner-content" class="row">
		
			<div id="main" class="large-12 medium-12 columns first" role="main">
		
				<?php echo $breadcrumb; ?>
		
				<header class="article-header section-header">
					<h2><?php the_archive_title();?></h2>
					<?php the_archive_description('<div class="taxonomy-description">', '</div>');?>
				</header>
				
				<!-- To see additional archive styles, visit the /parts directory -->
				<?php get_template_part( 'parts/loop', 'archive' ); ?>					
	
			</div> <!-- end #main -->
		
		</div> <!-- end #inner-content -->
		
	</div> <!-- end #content -->

<?php get_footer(); ?>