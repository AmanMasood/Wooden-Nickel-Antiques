<?php
// Theme support options
require_once(get_template_directory().'/assets/functions/theme-support.php'); 

// WP Head and other cleanup functions
require_once(get_template_directory().'/assets/functions/cleanup.php'); 

// Register scripts and stylesheets
require_once(get_template_directory().'/assets/functions/enqueue-scripts.php'); 

// Register custom menus and menu walkers
require_once(get_template_directory().'/assets/functions/menu.php'); 
require_once(get_template_directory().'/assets/functions/menu-walkers.php'); 

// Register sidebars/widget areas
require_once(get_template_directory().'/assets/functions/sidebar.php'); 

// Makes WordPress comments suck less
require_once(get_template_directory().'/assets/functions/comments.php'); 

// Replace 'older/newer' post links with numbered navigation
require_once(get_template_directory().'/assets/functions/page-navi.php'); 

// Adds support for multiple languages
require_once(get_template_directory().'/assets/translation/translation.php'); 

// Use this as a template for custom post types
require_once(get_template_directory().'/assets/functions/custom-post-type.php');

// Custom meta box functionality
include(get_template_directory().'/assets/functions/custom-meta-box.php');

// Adds site styles to the WordPress editor
//require_once(get_template_directory().'/assets/functions/editor-styles.php'); 

// Customize the WordPress login menu
// require_once(get_template_directory().'/assets/functions/login.php'); 

// Customize the WordPress admin
// require_once(get_template_directory().'/assets/functions/admin.php'); 

// Include product archives
add_filter('pre_get_posts', 'bwd_query_post_type');
function bwd_query_post_type($query) {
	if(is_category() || is_tag()) {
		$post_type = get_query_var('post_type');
		if (empty($post_type)) {
			$post_type = array('post','product');
			$query->set('post_type',$post_type);
		}
	return $query;
    }
}

// hide labels on gravity forms by default -- show for screen readers
add_filter('gform_enable_field_label_visibility_settings', '__return_true');

// send ga events for gravity forms
function generate_ga_event($label) { ?>
	<script>
	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
	
	ga('create', 'UA-18166597-1', 'auto');
	ga('send', {hitType: 'event',  eventCategory: 'Form',  eventAction: 'Submission',  eventLabel: '<?php echo $label; ?>',  eventValue: '15' });
	</script>
<?php 
}

function send_ga_events($entry, $form) {
	if($form['id'] == 2) { generate_ga_event('Contact Form'); }
	if($form['id'] == 1) { generate_ga_event('Sell Item'); }
}
add_action('gform_after_submission', 'send_ga_events', 10, 2);

// send ga events for product interest form (WPCF7)
add_action( 'wp_footer', 'add_ga_event_product_interest' );

function add_ga_event_product_interest() { ?>
	<script type="text/javascript">
		document.addEventListener('wpcf7mailsent', function(event) {
			if ( '110638' == event.detail.contactFormId ) {
				ga('send', {hitType: 'event',  eventCategory: 'Form',  eventAction: 'Submission',  eventLabel: 'Product Interest',  eventValue: '30' });
			}
		}, false);
	</script>
<?php
}


/**
 * Extend WordPress search to include custom fields
 */

/**
 * 1. Join posts and postmeta tables
 */
function cf_search_join( $join ) {
    global $wpdb;

    if ( is_search() ) {    
        $join .=' LEFT JOIN '.$wpdb->postmeta. ' ON '. $wpdb->posts . '.ID = ' . $wpdb->postmeta . '.post_id ';
    }

    return $join;
}
add_filter('posts_join', 'cf_search_join' );

/**
 * 2. Modify the search query with posts_where
 */
function cf_search_where( $where ) {
    global $pagenow, $wpdb;

    if ( is_search() ) {
        $where = preg_replace(
            "/\(\s*".$wpdb->posts.".post_title\s+LIKE\s*(\'[^\']+\')\s*\)/",
            "(".$wpdb->posts.".post_title LIKE $1) OR (".$wpdb->postmeta.".meta_value LIKE $1)", $where );
    }

    return $where;
}
add_filter( 'posts_where', 'cf_search_where' );

/**
 * 3. Prevent duplicates
 */
function cf_search_distinct( $where ) {
    global $wpdb;

    if ( is_search() ) {
        return "DISTINCT";
    }

    return $where;
}
add_filter( 'posts_distinct', 'cf_search_distinct' );