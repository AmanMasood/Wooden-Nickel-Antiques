<?php 
/**
 ** Template Name: Home
 ** WNA-Custom Theme
**/
?>
<?php get_header(); ?>

<!-- Main Banner -->
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<?php	
		$thumb_id = get_post_thumbnail_id();
		$thumb_url = wp_get_attachment_image_src($thumb_id,'full', true);
	?>
	<article id="home-banner" <?php post_class(''); ?> style="background-image:url('<?php echo $thumb_url[0]; ?>');" role="article" itemscope itemtype="http://schema.org/WebPage">
		<div class="dark-overlay">
			<header class="article-header">
				<div class="show-for-medium-up">
					<h1><img src="<?php echo site_url(); ?>/wp-content/uploads/2015/09/wna-logo-white.png" width="600" height="75" alt="Wooden Nickel Antiques" /></h1>
				</div>
				<div class="show-for-small-only">
					<img src="<?php echo site_url(); ?>/wp-content/uploads/2015/09/wna-logo-white-small.png" alt="Wooden Nickel Antiques" />
				</div>
			</header>
							
			<section class="entry-content" itemprop="articleBody">
				<?php the_content(); ?>
			</section>
								
			<footer class="article-footer">
			    <div class="button-group">
        			<a class="sell-item button alert radius">Sell Us Your Item</a>
        			<a href="#location" class="button info radius">Hours &amp; Location</a>
        		</div>			
			</footer>
		</div>
	</article>
<?php endwhile; endif; ?>		
<?php // removed temporarily
/*
<div class="section-header">
	<h2>COVID-19 Statement</h2>
</div>
<div class="entry-content max800">
	<?php echo get_post_meta($post->ID, 'COVID-19 Statement', true); ?>
</div>
*/
?>
<div class="section-header">
	<h2>Our Specialties</h2>
</div>
<div class="entry-content max800">
	<?php echo get_post_meta($post->ID, 'Our Specialties', true); ?>
</div>
<?php // Mosaic Menu
$mosaic_query = new WP_Query(array( 
	'post_type' => 'mosaic', 
	'posts_per_page' => 8,
	'orderby' => 'menu_order',
	'order' => 'ASC'					
	)
);

// init counter for use in stylesheet
$mosaic_num = 0; 

// start mosaic output
while ( $mosaic_query->have_posts() ) : $mosaic_query->the_post();
	
	// get our post data
	$mosaic_title = get_the_title();
	$mosaic_link = get_post_meta($post->ID,'URL',true);
	
	// format the data
	$mosaic_title = explode(" ",$mosaic_title);
	$mosaic_link = site_url() . $mosaic_link;
	
	?>

	<div id="mosaic-<?php echo $mosaic_num; ?>" class="mosaic-item">
		<a class="mosaic-link" href="<?php echo $mosaic_link; ?>">
			<?php the_post_thumbnail('mosaic_image','full'); ?>
			<div class="medium-overlay absolute-full">
				<p class="mosaic-title">
					<span class="oswald-medium"><?php echo $mosaic_title[0]; ?></span><br/>
					<?php echo $mosaic_title[1]; ?>
				</p>
			</div>
		</a>
	</div>

	<?php $mosaic_num++; ?>
<?php endwhile; // End Mosaic Query ?>

<!-- Start Content -->					
<div id="content">
	<div id="inner-content" class="row">
		<div id="main" class="large-12 medium-12 columns" role="main">
			<div id="home-carousel">
				<div class="section-header">
					<h2>New Arrivals</h2>
				</div>
				<div class="carousel-container">
				
				<?php // carousel
					$carousel_query = new WP_Query(array( 
						'post_type' => 'home-carousel', 
						'posts_per_page' => 20,
						'orderby' => 'menu_order',
						'order' => 'ASC'					
						)
					); 

					// start carousel output
					while ( $carousel_query->have_posts() ) : $carousel_query->the_post();
						$carousel_meta = get_post_meta($post->ID,'_llabs_meta',TRUE); ?>
						
					<div class="carousel-item">
						<?php the_post_thumbnail('carousel-image','full'); ?>
						<div class="medium-overlay overlay-on-hover absolute-full"><a href="<?php if (isset($carousel_meta['link'])) { echo $carousel_meta['link']; } ?>">
							<div class="carousel-text">
								<div class="carousel-title"><?php the_title(); ?></div>
								<div class="carousel-price"><?php the_content(); ?></div>
							</div>
						</a></div>
					</div>
						
				<?php endwhile; ?>
				</div>
			</div><!-- end carousel section -->
			
			<!-- location -->
			<div id="location" class="section-header">
				<h2>Location</h2>
			</div>
			<div id="location-section" class="row">
				<div class="large-6 medium-6 columns map-container">
					<iframe width="100%" height="400" frameborder="0" style="border:0" loading="lazy" allowfullscreen src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA7ge8x3tS8QQ_ZO-naz1A3L2eYgSVBkMA&q=Wooden+Nickel+Antiques,Cincinnati,+OH"></iframe>
				</div>
				<div class="large-6 medium-6 columns entry-content">
					<p><strong>Visit Our Store</strong><br/>
					1410 Central Parkway<br/>
					Cincinnati, Ohio 45202<br/>
					Phone: (513) 241-2985<br/></p>
					<p>We are open Monday to Saturday, 10:00 a.m. to 4:00 p.m. Closed Sunday.</p>
					<p>Our inventory is regularly changing, so stop in frequently to see our unique new home decor and antique furniture!</p>
					<div class="button-group">
						<a href="contact-us" class="button success radius">Contact Us</a>
						<a class="sell-item button primary radius">Sell Us Your Item</a>
					</div>
				</div>
			</div>
			<!-- location -->
			
			<!-- whats inside -->
			<div class="section-header">
				<h2>What's Inside?</h2>
			</div>
			<div id="inside-section" class="row">
			
				<?php // whats inside items
					$inside_query = new WP_Query(array( 
						'post_type' => 'blurb', 
						'posts_per_page' => 8,
						'orderby' => 'menu_order',
						'order' => 'ASC'					
						)
					); 

					// start whats inside output
					while ( $inside_query->have_posts() ) : $inside_query->the_post(); ?>
					
						<div class="large-1 medium-1 small-3 columns">
							<?php the_post_thumbnail('full'); ?>
						</div>
						<div class="large-2 medium-5 small-9 columns entry-content">
							<h3><?php the_title(); ?>
							<?php the_content(); ?>
						</div>
					
				<?php endwhile; ?>
			
			</div>
		</div> <!-- end #main -->		
	</div> <!-- end #inner-content -->
</div> <!-- end #content -->
<?php get_footer(); ?>